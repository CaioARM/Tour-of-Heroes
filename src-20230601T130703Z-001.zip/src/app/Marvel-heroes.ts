import { Hero } from './hero';

export const HEROES: Hero[] = [
  { id: 12, name: 'Homem-Aranha' },
  { id: 13, name: 'Homem de Ferro' },
  { id: 14, name: 'Capitao America' },
  { id: 15, name: 'Viuva negra' },
  { id: 16, name: 'Thor' },
  { id: 17, name: 'Doutor estranho' },
  { id: 18, name: 'Gaviao Arqueiro' },
  { id: 19, name: 'Homem formiga' },
  { id: 20, name: 'Capita Marvel' }
];